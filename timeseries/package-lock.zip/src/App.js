import React, { useState } from 'react';
import Papa from 'papaparse';
import './main.css'
import { resample,  parseData, sortData} from './resampler';

function App() {
  const [csvData, setCsvData] = useState([]);
  const [fillMethod, setFillMethod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [fillOnColumn, setFillOn] = useState(null);
  const [constValue, setConstval] = useState(null);

  const handleConstvalue = (value) => {
    setConstval(value);
  }

  const handleFileUpload = (event) => {
    const files = event.target.files;
    const fileReaders = [];
  
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileReader = new FileReader();
  
      fileReader.onload = (e) => {
        const result = e.target.result;
        let csv = Papa.parse(result, {
          header: false,
          delimiter: ",",
          skipEmptyLines: true,
        });
        csv = csv.data.slice(1, csv.length);
        setCsvData((csvData) => [...csvData, csv]);
      };

      fileReader.readAsText(file);
      fileReaders.push(fileReader);
    }
  };

  const handleFillMethodChange = (event) => {
    setFillMethod(event.target.value);
  };

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  const handleFillon = (fill) => {
    setFillOn(fill);
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    let data = [...csvData[0]];
    //data = sortData(data);
    let worker = new Worker("./worker.js");
    worker.postMessage(data);
    worker.onmessage = function (e){
      let data = e.data;
      console.log(data);
    }
    // Process the form data here
    //console.log('CSV Data:', csvData);
    console.log('Fill Method:', fillMethod);
    console.log('Start Date:', startDate);
    console.log('End Date:', endDate);
  };

  return (
    <div className="min-h-full h-screen w-full flex justify-center py-20 bg-[#f8fafc]">
        <section class="max-h-2/4 h-2/3 p-6 mx-auto bg-indigo-400 rounded-md shadow-md dark:bg-gray-800">
          <h1 class="text-xl font-bold text-white capitalize dark:text-white">Rainfall Processor</h1>
          <form onSubmit={handleSubmit}>
            <div class="grid grid-cols-1 gap-4 mt-4 sm:grid-cols-2">
              <div>
                <label class="text-white dark:text-gray-200" for="username">Select CSV File(s):</label>
                <input type="file" multiple onChange={handleFileUpload} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring" />
              </div>
              <div>
                <label class="text-white dark:text-gray-200" for="username">Fill Gaps:</label>
                <select value={fillMethod} onChange={handleFillMethodChange} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring">
                  <option value="">Select Fill Method</option>
                  <option value="bfill">Backfill (bfill)</option>
                  <option value="ffill">Forward Fill (ffill)</option>
                  <option value="constant">Constant Value</option>
                  <option value="interpolate">Interpolate</option>
                </select>
              </div>
              <div>
                <label class="text-white dark:text-gray-200" for="username">Start DateTime:</label>
                <input
                  type="datetime-local"
                  value={startDate} // Make sure `endDate` follows the format "yyyy-MM-ddThh:mm"
                  onChange={handleStartDateChange} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring"
                />
              </div>
              <div>
                <label class="text-white dark:text-gray-200" for="username">End DateTime:</label>
                <input type="datetime-local" name="" value={endDate} onChange={handleEndDateChange} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring" />
              </div>
              <div>
                <label class="text-white dark:text-gray-200" for="username">Column Index for interpolation:</label>
                <input type="number" onChange={handleFillon} value={fillOnColumn} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring" />
              </div>
              <div>
                <label class="text-white dark:text-gray-200" for="username">Constant Value for constant fill:</label>
                <input type="number" onChange={handleConstvalue} value={constValue} class="block w-full px-4 py-2 mt-2 text-gray-700 bg-white border border-gray-300 rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring" />
              </div>
              <div class="flex justify-center mt-6">
                <button class="px-6 py-2 leading-5 text-white transition-colors duration-200 transform bg-pink-500 rounded-md hover:bg-pink-700 focus:outline-none focus:bg-gray-600">Process</button>
              </div>
            </div>
          </form>
        </section>
      </div>
  );
}

export default App;