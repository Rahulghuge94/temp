

/**
 * Parses a date string to a JavaScript Date object.
 * @param {string} dateString - The date string to be parsed.
 * @returns {Date} The parsed Date object.
 */
function parseStringDate(dateString) {
    let date = null;

    if (dateString.includes("/")) {
        dateString = dateString.replaceAll("/", "-")
    }

    date = new Date(dateString);
    return date;
}

/**
 * Parses date strings within a data array to JavaScript Date objects.
 * @param {Array<Array<any>>} dataArr - The array containing date strings as the first element of each inner array.
 * @param {number} datetimeColumn - column number to identify the datetime index in array.
 * @returns {Array<Array<any>>} The data array with date strings converted to Date objects.
 */
function parseData(dataArr, datetimeColumn) {
    let data = dataArr.map((d) => {
        d[datetimeColumn] = parseStringDate(d[datetimeColumn]);
        return d;
    });
}

/**
 * Generates an array of timestamps between two dates at a specified time step.
 * @param {Date} fromDate - The start date.
 * @param {Date} toDate - The end date.
 * @param {number} timeStepMS - The time step in milliseconds.
 * @returns {Array<number>} An array of timestamps at the specified time step between the provided dates.
 */
function getTimesteps(fromDate, toDate, timeStepMS) {
    let tToDate = toDate.getTime();
    let tFromDate = fromDate.getTime();
    let tempDate = tFromDate;
    let timestepArr = [];

    while (tempDate < tToDate) {
        let remainder = tempDate % timeStepMS;
        if (remainder == 0 && tempDate) {
            timestepArr.push(tempDate);
            tempDate += timeStepMS;
        } else {
            let diff = timeStepMS - remainder;
            //timestepArr.push(tempDate + diff);
            tempDate += diff;
        }
    }
    return timestepArr;
}

/**
 * Interpolates a value given two data points and a target point.
 * @param {number} x0 - The x-coordinate of the first data point.
 * @param {number} x1 - The x-coordinate of the second data point.
 * @param {number} y0 - The y-coordinate of the first data point.
 * @param {number} y1 - The y-coordinate of the second data point.
 * @param {number} x - The x-coordinate of the target point for interpolation.
 * @returns {number} The interpolated value at the target x-coordinate.
 */
function interpolateValue(x0, x1, y0, y1, x) {
    let y = y0 + ((x - x0) * ((y1 - y0) / (x1 - x0)))
    return y
}

/**
 * Fills the values for the given timestamps based on a provided array.
 * @param {Array<number>} dataArr - The array of timestamps.
 * @param {Array<any>} dataFillArray - The array to be used for filling values.
 * @param {number} datetimeColumn - column number to identify the datetime index in array.
 * @returns {Array<Array<any>>} The array containing filled values corresponding to the timestamps.
 */
function fillValues(dataArr, dataFillArray, datetimeColumn) {
    let data = [];
    for (let ts of dataArr) {
        let _dataFillArray = [...dataFillArray]
        _dataFillArray[datetimeColumn] = ts;
        data.push(_dataFillArray);
    }
    return data;
}

/**
 * Adjusts the provided data to include start and end timestamps if needed.
 * @param {string | Date} _from - The start timestamp or date.
 * @param {string | Date} _to - The end timestamp or date.
 * @param {Array<Array<any>>} data - The data array to be adjusted.
 * @param {number} datetimeColumn - column number to identify the datetime index in array.
 * @returns {Array<Array<any>>} The adjusted data array.
 */
function AdjustFromTo(_from, _to, data, datetimeColumn) {
    let _data = [...data];
    let fromDate = new Date(_from).getTime();
    let toDate = new Date(_to).getTime();

    if (_data[0][datetimeColumn].getTime() > fromDate) {
        let tArr = [..._data[0]];
        tArr[datetimeColumn] = new Date(_from);
        _data.splice(0, 0, tArr);
    }
    else if (_data[0][datetimeColumn].getTime() < fromDate) {
        for (let i = 1; i < _data.length; i++) {
            if (_data[i][datetimeColumn].getTime() > fromDate) {
                let tArr = [..._data[i - 1]];
                tArr[datetimeColumn] = new Date(_from);
                _data.splice(i, 0, tArr);
                _data = _data.slice(i, _data.length);
                break;
            }
            if (_data[i][datetimeColumn].getTime() == fromDate) {
                _data = _data.slice(i, _data.length);
                break;
            }
        }
    }

    if (_data[_data.length - 1][datetimeColumn].getTime() < toDate) {
        let tArr = [..._data[_data.length - 1]];
        tArr[datetimeColumn] = new Date(_to);
        _data.push(tArr);
    }
    else if (_data[_data.length - 1][datetimeColumn].getTime() > toDate) {
        for (let i = _data.length - 1; i >= 0; i--) {
            if (_data[i][datetimeColumn].getTime() < toDate) {
                let tArr = [..._data[i + 1]];
                tArr[datetimeColumn] = new Date(_to);
                _data.splice(i + 1, 0, tArr);
                _data = _data.slice(0, i + 2);
                break;
            }
            if (_data[i][datetimeColumn].getTime() == toDate) {
                _data = _data.slice(0, i + 1);
                break;
            }
        }
    }
    return _data;
}

/**
 * Resamples the data array based on the provided parameters.
 * @param {Array<Array<any>>} dataArr - The input data array.
 * @param {string} fillMethod - The method used to fill missing values ("bfill", "ffill", "constant", "interpolate").
 * @param {any} fillOn - The value or index to be filled in case of "constant" or "interpolate" method.
 * @param {number} timeStepMS - The time step in milliseconds for resampling.
 * @param {any} constValue - The constant value used in case of "constant" method.
 * @param {number} datetimeColumn - datetime column index in list.
 * @returns {Array<Array<any>>} The resampled data array.
 */
function resample(dataArr, fillMethod, fillOn, timeStepMS, constValue, datetimeColumn) {
    let resampledData = [];
    let constValAr = dataArr[0].map((x) => constValue);
    let lastValueAr = dataArr[0];
    dataArr.push(dataArr[dataArr.length - 1]) //insert 1 extra element so ensure it does not exclude any item.

    for (let i = 1; i < dataArr.length; i++) {
        let prevValueAr = dataArr[i - 1];
        let currValueAr = dataArr[i];
        let tSteps;
        tSteps = getTimesteps(prevValueAr[datetimeColumn], currValueAr[datetimeColumn], timeStepMS);

        if (tSteps && tSteps.length > 0) {
            let dataFillArray;
            
            if (fillMethod == "bfill") {
                dataFillArray = [...prevValueAr];
                let data = fillValues(tSteps, dataFillArray);
                resampledData = resampledData.concat(data);
            }

            if (fillMethod == "ffill") {
                dataFillArray = [...currValueAr];
                let data = fillValues(tSteps, dataFillArray);
                resampledData = resampledData.concat(data);
            }

            if (fillMethod == "constant") {
                dataFillArray = constValAr;
                let data = fillValues(tSteps, dataFillArray);
                resampledData = resampledData.concat(data);
            }

            if (fillMethod == "interpolate") {
                let x0 = prevValueAr[datetimeColumn], x1 = currValueAr[datetimeColumn], y0 = prevValueAr[fillOn], y1 = currValueAr[fillOn];
                
                let data = [];

                for (let i = 0; i < tSteps.length; i++) {
                    dataFillArray = [...prevValueAr];
                    dataFillArray[fillOn] = interpolateValue(x0, x1, y0, y1, tSteps[i]);
                    dataFillArray[0] = tSteps[i];
                    data.push(dataFillArray);
                }

                resampledData = resampledData.concat(data);
            }
        }
    }
    return resampledData;
}

/**
 * Sorts the data array based on the timestamps.
 * @param {Array<Array<any>>} data - The data array to be sorted.
 * @returns {Array<Array<any>>} The sorted data array.
 */
function sortData(data) {
    return data.sort((a, b) => a[0] - b[0]);
}

/**
 * Joins the datetime  from array.
 * @param {Array<Array<any>>} data - The data array to be sorted.
 * @param {number} dateIndex - The date column index.
 * @param {number} timeIndex - The time column index.
 * @returns {Array<Array<any>>} The sorted data array.
 */
function joinDateTimeCols(data, dateIndex, timeIndex) {
    let _data = data.map((item) => {
        let DT = String(item[dateIndex]) + " " + String(item[timeIndex]);
        let ar = [DT, ...item];
        return ar;
    });
    return _data;
}

export {
    parseStringDate, parseData, getTimesteps, sortData,
    interpolateValue, fillValues, AdjustFromTo, resample, 
    joinDateTimeCols
}
