import {
    parseStringDate, parseData, getTimesteps, sortData,
    interpolateValue, fillValues, AdjustFromTo, resample, 
    joinDateTimeCols
} from "./resampler";

onmessage = function(e){
    let started = performance.now();
    let data = e.data;
    data = joinDateTimeCols(data, 1, 2);
    data = parseData(data)
    sortData(data);
    data = resample(data, "bfill", null, 300000, null, 0);
    postMessage(data);
    let stopped = performance.now();
    console.log(`Operation started at: ${started}, Stopped at ${stopped}.`);
    console.log(`It took: ${stopped - started} time.`);
}

export {onmessage};