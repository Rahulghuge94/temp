__title__ = "pytvlwcharts"
__description__ = "An Experimental Python Wrapper For Tradingview's Lightweight-Charts To Be Used In Notebook Environments."
__url__ = "https://github.com/TechfaneTechnologies"
__download_url__ = "https://github.com/TechfaneTechnologies/pytvlwcharts"
__version__ = "0.0.1"
__author__ = "Techfane Technology Pvt. Ltd. (India)"
__author_email__ = "moonedrjune@gmail.com"
__license__ = ("MIT", "Apache-2.0")
